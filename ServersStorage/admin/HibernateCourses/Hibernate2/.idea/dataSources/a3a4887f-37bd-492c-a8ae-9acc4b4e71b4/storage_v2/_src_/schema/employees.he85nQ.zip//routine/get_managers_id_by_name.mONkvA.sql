create
    definer = root@localhost function get_managers_id_by_name(managers_name char(14), managers_surname char(16)) returns int
    return (select ifnull((select man.emp_no  as managers_number 
from dept_manager as man
left join employees as emp on emp.emp_no = man.emp_no
where emp.first_name = managers_name 
and emp.last_name = managers_surname limit 1), 
0));

