create
    definer = root@localhost procedure fire_worker(IN employees_id int, IN receive_payment int)
begin
declare exit handler for sqlexception
	begin
		rollback;
        select'something was wrong/чтото пошло не так';
	end;

     start transaction;
		update dept_emp set to_date = sysdate() where emp_no = employees_id and to_date = '9999-01-01';
		update salaries set to_date = sysdate(), salary = receive_payment where emp_no = employees_id and to_date = '9999-01-01'; 
		commit;
end;

