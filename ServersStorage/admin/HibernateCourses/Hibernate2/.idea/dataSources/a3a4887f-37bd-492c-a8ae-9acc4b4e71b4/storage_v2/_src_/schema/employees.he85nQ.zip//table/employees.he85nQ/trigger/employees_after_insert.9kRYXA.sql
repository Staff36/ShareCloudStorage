create definer = root@localhost trigger employees_AFTER_INSERT
    after insert
    on employees
    for each row
BEGIN
insert salaries (emp_no, salary, from_date, to_date) values (new.emp_no, 10000, curdate(), curdate());
END;

