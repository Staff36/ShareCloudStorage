create
    definer = root@localhost function get_manager_id_if_exists(managers_name char, managers_surname char) returns int
    return (select emp.emp_no from dept_manager as man 
left join employees as emp on emp.emp_no = man.emp_no 
where emp.first_name = managers_name 
and emp.last_name = managers_surname and managers_surname =  emp.emp_no);

