create view get_average_salary_by_departments as
select `dept`.`dept_name` AS `dept_name`, ceiling(avg(`sal`.`salary`)) AS `ceiling(avg(sal.salary))`
from ((`employees`.`departments` `dept` left join `employees`.`dept_emp` `deem` on ((`dept`.`dept_no` = `deem`.`dept_no`)))
         left join `employees`.`salaries` `sal` on ((`deem`.`emp_no` = `sal`.`emp_no`)))
where (`deem`.`to_date` = '9999-01-01')
group by `dept`.`dept_name`;

